import java.io.*;
import java.nio.file.*;

public class ReadWriteFile {
    public static void main(String[] args) {
        Path path = Paths.get(System.getProperty("user.home"), "Desktop", "myFile.txt");

        try {
            // Check if the file has content already
            String content = Files.readString(path);
            System.out.println("Content of myFile.txt:");
            System.out.println(content);

            // Append new text with a line separator before if needed
            if (!content.endsWith(System.lineSeparator())) {
                content += System.lineSeparator();  // Ensure there is a line break
            }
            String newText = "A new string";
            Files.writeString(path, content + newText + System.lineSeparator(), StandardOpenOption.CREATE, StandardOpenOption.WRITE);
        } catch (IOException e) {
            System.err.println("An error occurred: " + e.getMessage());
        }
    }
}

